package com.example.comp490;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NewList extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_list);

        Button button = (Button) findViewById(R.id.back);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openList();
            }
        });

        Button button2 = (Button) findViewById(R.id.newdecision);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewDecision();
            }
        });
    }

    public void openList(){
        Intent intent = new Intent(this, List.class);
        startActivity(intent);
    }
    public void openNewDecision(){
        Intent intent = new Intent(this, NewDecision.class);
        startActivity(intent);
    }
}