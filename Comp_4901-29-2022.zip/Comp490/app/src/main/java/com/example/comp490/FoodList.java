package com.example.comp490;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
//import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;

import java.util.ArrayList;

public class FoodList extends AppCompatActivity {
    private Button button;

    public static ArrayList<String> food;
    int min = 0;
    int max = 7;

    //private static final String TAG = "activity_food_list";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //int[] foodArray = new int[3];
        //foodArray[0]=1;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_list);


        //HOW TO DISPLAY LIST OF STRINGS: https://stackoverflow.com/questions/20750118/displaying-list-of-strings-in-android/20750202
        String[] test = new String[]{"Burger", "Sushi", "Ramen", "Mexican", "Indian", "Persian", "Ugandan", "Health Potion"};
        final ArrayList<String> list = new ArrayList<String>();
        for (int i = 0; i < test.length; ++i) {
            list.add(test[i]);
        }

        ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        ListView foodlistview = (ListView) findViewById(R.id.foodlistview);
        foodlistview.setAdapter(adapter);
        //END OF DISPLAY LIST OF THINGS
        //idk wtf

       /* food = new ArrayList<>();
        food.add("Burger");
        food.add("Sushi");
        food.add("Ramen");
        food.add("Mexican");
        food.add("Indian");
        food.add("Persian");
        //Math.floor(Math.random()*(max-min+1)+min)
        for (int i = 0; i < food.size(); i++){
            food.get(i);
        }*/

        Button button = (Button) findViewById(R.id.back);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openList();
            }
        });
        Button button2 = (Button) findViewById(R.id.randomize);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String output;
                int index = (int) (Math.random() * test.length);
                System.out.println(test[index]);
                //double random_num = Math.floor(Math.random()*(max-min+1)+min);
                /*for (int i = 0; i < test.length; i++) {
                    int index = (int) (Math.random() * test.length);
                    //test[index];
                    output = test[index];
                }*/
            }
            //ArrayAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
            //ListView foodlistview = (ListView) findViewById(R.id.foodlistview);
            //foodlistview.setAdapter(adapter);
        });
    }

        //Don't touch this it's fucking broken
        /*
        // inflate the layout of the popup window
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_food_list, null);

        // create the popup window
        int width = ConstraintLayout.LayoutParams.WRAP_CONTENT;
        int height = ConstraintLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window tolken
        //View view = null;
        popupWindow.showAtLocation(this.findViewById(R.id.foodlistview), Gravity.CENTER, 0, 0);

        // dismiss the popup window when touched
        popupView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                popupWindow.dismiss();
                return true;
            }
        });
    }*/

    public void openList(){
        Intent intent = new Intent(this, List.class);
        startActivity(intent);
    }
}
