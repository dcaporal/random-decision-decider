package com.example.comp490;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
//imported EditText, TextView 11/11 2:37 PM
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class NewDecision extends AppCompatActivity {

    EditText input;

    private static final String KEY_INPUT1 = "key_input1";

    private String newDecision;
    private TextView test;
    TextView emptyBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_decision);

        input = (EditText) findViewById(R.id.decision_input);
        emptyBox = (TextView) findViewById(R.id.emptyTest);

        if (savedInstanceState != null) {
            String savedFirstInput = savedInstanceState.getString(KEY_INPUT1);
            emptyBox.setText(savedFirstInput);
        } else {
            Toast.makeText(this, "New Entry", Toast.LENGTH_SHORT).show();
        }

        Button button = (Button) findViewById(R.id.back);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openList();
            }
        });



        Button enterButton = (Button) findViewById(R.id.enterbutton);
        enterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //save textbox input to list
                saveView(v);
            }
        });
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putString(KEY_INPUT1, input.getText().toString());
        super.onSaveInstanceState(savedInstanceState);
    }

    public void openList(){
        Intent intent = new Intent(this, List.class);
        startActivity(intent);
    }

    //returns input to be shared with other classes
    public EditText getInput(){
        return input;
    }

    public void saveView(View view) {
        emptyBox.setText(input.getText().toString().trim());
    }
}